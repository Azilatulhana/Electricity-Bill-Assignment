package com.example.electriccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText numberElectricity, rebate;
    Button btnCalculate, btnClear;
    TextView electricityOutput, finalCostOutput, rebateOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberElectricity = findViewById(R.id.numberElectricity);
        rebate = findViewById(R.id.rebate);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnClear = findViewById(R.id.btnClear);
        electricityOutput = findViewById(R.id.electricityOutput);
        finalCostOutput = findViewById(R.id.finalCostOutput);
        rebateOutput = findViewById(R.id.rebateOutput);

        btnCalculate.setOnClickListener(this);
        btnClear.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnCalculate) {
            String inputElectricity = numberElectricity.getText().toString();
            String inputRebate = rebate.getText().toString();

            if (TextUtils.isEmpty(inputElectricity) || TextUtils.isEmpty(inputRebate)) {
                Toast.makeText(this, "Please enter values for electricity and rebate", Toast.LENGTH_SHORT).show();
            } else {
                double electricity = Double.parseDouble(inputElectricity);
                double rebateValue = Double.parseDouble(inputRebate);

                double electricityResult = calculateElectricityBill(electricity);
                double finalCost = electricityResult - calculateRebate(electricityResult, rebateValue);

                DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
                decimalFormat.setRoundingMode(RoundingMode.DOWN); // Set rounding mode to down

                String formattedElectricityResult = decimalFormat.format(electricityResult / 100.0);
                String formattedFinalCost = decimalFormat.format(finalCost / 100.0);
                String formattedRebateValue = decimalFormat.format(calculateRebate(electricityResult, rebateValue) / 100.0);

                String electricityText = getString(R.string.electricity_output, formattedElectricityResult);
                String finalCostText = getString(R.string.final_cost_output, formattedFinalCost);
                String rebateText = getString(R.string.rebate_output, formattedRebateValue);

                electricityOutput.setText(electricityText);
                finalCostOutput.setText(finalCostText);
                rebateOutput.setText(rebateText);

                Toast.makeText(this, finalCostText, Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.btnClear) {
            numberElectricity.setText("");
            rebate.setText("");
            // Reset the TextViews to show the labels without values
            electricityOutput.setText("Electricity Cost:");
            finalCostOutput.setText("Final Cost:");
            rebateOutput.setText("Rebate:");
        }
    }

    private double calculateElectricityBill(double electricity) {
        double totalCharge = 0.0;

        if (electricity <= 200) {
            totalCharge = electricity * 21.8;
        } else if (electricity <= 300) {
            totalCharge = (200 * 21.8) + ((electricity - 200) * 33.4);
        } else if (electricity <= 600) {
            totalCharge = (200 * 21.8) + (100 * 33.4) + ((electricity - 300) * 51.6);
        } else if (electricity > 600) {
            totalCharge = (200 * 21.8) + (100 * 33.4) + (300 * 51.6) + ((electricity - 600) * 54.6);
        } else {
            totalCharge = (200 * 21.8) + (100 * 33.4) + (300 * 51.6) + (300 * 54.6) + ((electricity - 900) * 57.1);
        }

        return totalCharge;
    }

    private double calculateRebate(double electricityBill, double rebatePercentage) {
        return electricityBill * (rebatePercentage / 100.0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.about) {
            Intent aboutIntent = new Intent(this, AboutActivity.class);
            startActivity(aboutIntent);
            return true;
        } else if (itemId == R.id.instruction) {
            Intent instructionsIntent = new Intent(this, InstructionActivity.class);
            startActivity(instructionsIntent);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
}
